#!/bin/sh

java -cp ../../../lib/JRecordCodeGen.jar TstWalkerBuilderDtar020.java
