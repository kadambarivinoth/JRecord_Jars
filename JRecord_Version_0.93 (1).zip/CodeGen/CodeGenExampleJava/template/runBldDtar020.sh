#!/bin/sh

java -cp ../../../lib/JRecordCodeGen.jar BldDTAR020.java
